# Trail 2026-10-19 性能证据包

先读 docs/benchmarks/2026-10-19-Trail-性能补测与简历证据.md，再读面试说明。

主结果：3 个固定策略与标的组合，30 对真实接口测试，数据获取中位耗时相较串行对照从 4.540s 降到 1.344s，降低 70.4%。串行对照不是历史版本，不包含模型综合和 UI 耗时。初始综合预检的两项失败仍保留。

artifacts/ 中包含原始数据、配对 CSV、协议、独立审计和完整正确性报告；scripts/bench/ 中为未来复测脚本。计时使用的原始脚本位于 artifacts/research-fetch-live-20261019/source-snapshot/，与 manifest.json 哈希对应；当前脚本只增加了自动存源码快照及失败退出码。

SHA256SUMS.json 是包内逐文件哈希清单。复现需要 Trail 仓库、对应代码和既有依赖/Longbridge 授权，本 ZIP 不是完整项目或独立安装包。未包含账号令牌、私有配置或持仓数据。
