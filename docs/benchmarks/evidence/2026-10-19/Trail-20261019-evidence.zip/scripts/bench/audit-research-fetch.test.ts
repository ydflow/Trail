import { describe, expect, it } from 'bun:test';
import { median, observedConcurrency, strictPayload } from './audit-research-fetch.ts';
describe('benchmark evidence validation',()=>{
  it('calculates odd/even medians without reordering raw input',()=>{
    const xs=[9,1,4]; expect(median(xs)).toBe(4); expect(xs).toEqual([9,1,4]); expect(median([2,8])).toBe(5); expect(median([])).toBeNull();
  });
  it('rejects financial statement shells without numeric financial data',()=>{
    expect(strictPayload('company.financials',{symbol:'AAPL.US',statements:{IS:{},BS:{},CF:{}}})).toBe(false);
    const statement={indicators:[{accounts:[{field:'Revenue',values:[{value:100}]}]}]};
    expect(strictPayload('company.financials',{symbol:'AAPL.US',statements:{IS:statement,BS:statement,CF:statement}})).toBe(true);
  });
  it('rejects empty news/forecasts and unrecognized payloads',()=>{
    expect(strictPayload('research.news',[])).toBe(false);expect(strictPayload('company.earnings',[])).toBe(false);
    expect(strictPayload('company.earnings',[{epsMean:'12'}])).toBe(false);
    expect(strictPayload('company.dividends',[])).toBe(true);expect(strictPayload('unknown',{})).toBe(false);
  });
  it('recomputes overlap rather than trusting a claimed concurrency number',()=>{
    expect(observedConcurrency([{startedMs:0,finishedMs:2},{startedMs:1,finishedMs:3}])).toBe(2);
    expect(observedConcurrency([{startedMs:0,finishedMs:2},{startedMs:2,finishedMs:3}])).toBe(1);
  });
});
